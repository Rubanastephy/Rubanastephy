# Jolly Jumper !!

**Jolly Jumper (version - 1.0.1)** is infinite jumping style game, highly inspired by Doodle jump.
This game is made in **Phaserjs** and it also open-sourced you can fork it here jolly-jumper. 
Supported Browser - **Opera 33.0, Chrome - Version 47.0.2526.73, Firefox Version - 40.0.2.**
Its my very first approach to be an indie game developer, hope you enjoyed this game.

**Android & windows version is coming soon.

## Play It

[Play on Github](http://shohan4556.github.io/jolly-jumper/)

[Play on itch.io](http://shohan4556.itch.io/jolly-jumper)

[Play on Gamejolt](http://gamejolt.com/games/jolly-jumper/112782#close)

**Supported Browser - Opera 33.0, Chrome - Version 47.0.2526.73, Firefox Version - 40.0.2.**

## Contributing

1. Fork it!
2. Submit a pull request :)

## Credits

Design & Develop : Shohan

## License

MIT License
